__name__ = "PSD Convert"
__all__ = ["BatchConvertPSD", "ConvertPSD"]

from psdconvert.convert import BatchConvertPSD, ConvertPSD
